
import pandas as pd

def load_and_clean_data(path="data/hotel_bookings.csv"):
    df = pd.read_csv(path)
    df.dropna(subset=["hotel", "arrival_date_year", "adr"], inplace=True)
    df.fillna({"country": "Unknown"}, inplace=True)
    df["arrival_date"] = pd.to_datetime(
        df["arrival_date_year"].astype(str) + "-" +
        df["arrival_date_month"] + "-" +
        df["arrival_date_day_of_month"].astype(str),
        errors="coerce"
    )
    return df
