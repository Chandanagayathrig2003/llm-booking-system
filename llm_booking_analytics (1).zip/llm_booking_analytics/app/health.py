
def check_health():
    try:
        import faiss, pandas, transformers
        return {"status": "healthy"}
    except Exception as e:
        return {"status": "unhealthy", "error": str(e)}
