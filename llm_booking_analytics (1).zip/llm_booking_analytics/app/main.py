
from fastapi import FastAPI
from app.utils import load_and_clean_data
from app.analytics import *
from app.rag import query_rag
from app.models import Question
from app.health import check_health

app = FastAPI()
df = load_and_clean_data()

@app.post("/analytics")
def analytics():
    return {
        "revenue": revenue_trend(df),
        "cancellation_rate": cancellation_rate(df),
        "geo_distribution": geo_distribution(df),
        "lead_time": lead_time_dist(df),
    }

@app.post("/ask")
def ask(question: Question):
    results = query_rag(question.query)
    return {"response": results}

@app.get("/health")
def health():
    return check_health()
