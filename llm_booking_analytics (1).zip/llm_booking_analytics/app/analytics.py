
def revenue_trend(df):
    trend = df.groupby(df["arrival_date"].dt.to_period("M"))["adr"].sum().reset_index()
    trend.columns = ["Month", "Revenue"]
    return trend.to_dict(orient="records")

def cancellation_rate(df):
    rate = df["is_canceled"].mean() * 100
    return {"cancellation_rate_percent": round(rate, 2)}

def geo_distribution(df):
    geo = df["country"].value_counts().head(10)
    return geo.to_dict()

def lead_time_dist(df):
    return df["lead_time"].describe().to_dict()
