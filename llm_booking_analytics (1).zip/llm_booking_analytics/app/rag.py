
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
import json

model = SentenceTransformer('all-MiniLM-L6-v2')

def prepare_rag_data(df, index_path="vector_store/index.faiss"):
    records = df.to_dict(orient="records")
    texts = [json.dumps(rec) for rec in records]
    embeddings = model.encode(texts)

    index = faiss.IndexFlatL2(embeddings.shape[1])
    index.add(np.array(embeddings))
    faiss.write_index(index, index_path)

    with open("vector_store/data.json", "w") as f:
        json.dump(texts, f)

def query_rag(question, top_k=5):
    index = faiss.read_index("vector_store/index.faiss")
    with open("vector_store/data.json") as f:
        data = json.load(f)

    q_embedding = model.encode([question])
    D, I = index.search(q_embedding, top_k)
    hits = [data[i] for i in I[0]]
    return hits
